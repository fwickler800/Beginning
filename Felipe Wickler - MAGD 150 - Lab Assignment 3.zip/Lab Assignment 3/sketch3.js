let d = 0;
let colorVal = 0;
function setup() {
  
  createCanvas(400, 400);
  background(220);
  colorMode(RGB,200);
  frameRate(55);
  
}

function draw() {
  
  if (mouseIsPressed === true) {
    fill(colorVal);
    line(pmouseX, pmouseY, mouseX, mouseY);
    d = dist(pmouseX, pmouseY, mouseX, mouseY);
    //text(d, 50, 50);
  }
  
}
function doubleClicked() {
  var r = color(200,0,0);
  var y = color(200,200,0);                        
  if (colorVal == r) {
    colorVal = y;
  } else if (colorVal == y) {
    colorVal = r;
  }
  
}