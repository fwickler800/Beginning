let x = 200;
let y = 200;
let speedX = 2;
let speedY = 2;
let size = 50;
let growing = true;
let ballColor = [255, 0, 0];
let angle = 0;

function setup() {
  
  createCanvas(1000, 1000);
    
}

function draw() {
  
  background(220);

  x += speedX;
  y += speedY;

  if (x >= width - size / 2) {
    
    x = width - size / 2;
    speedX *= -1;
            
  } else if (x <= size / 2) {
    
    x = size / 2;
    speedX *= -1;

  }

  if (y >= height - size / 2) {
                
    y = height - size / 2;
    speedY *= -1;
            
  } else if (y <= size / 2) {
                
    y = size / 2;
    speedY *= -1;
            
  }

  if (growing) {
    
    size += 1;
    
  } else {
    
    size -= 1;
    
  }

  if (size > 100 || size < 30) {
    
    growing = !growing;
    
  }

  fill(ballColor);
  
  ellipse(x, y, size, size);
  
  let numOrbits = 50; 
  let orbitRadius = 300;

  for (let i = 0; i < numOrbits; i++) {
    
    let angleOffset = (TWO_PI / numOrbits) * i;
    let orbitX = x + orbitRadius * cos(angle + angleOffset);
    let orbitY = y + orbitRadius * sin(angle + angleOffset);

    fill(100, 150, 255);
    ellipse(orbitX, orbitY, size / 3, size / 3);
    
  }

  angle += 0.05;
        
}

function mousePressed() {
  
  speedX = 0;
  speedY = 0;
  
}

function mouseClicked() {
  
  ballColor = [random(255), random(255), random(255)];
  speedX = 2;
  speedY = 2;

}