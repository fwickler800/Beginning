// canvas size and divisions need to be fixed

let basket;
let items = [];
let score = 0;
let gameOver = false;

// implement proper timer later
// let fallingObjectTimer = 60;

function preload() {


}

function drawSprites() {


}

function createSprite() {


}

function setup() {

  createCanvas(400, 600);
  basket = createSprite(width / 2, height - 50, 80, 20);

}

function draw() {
  
  background(200);

  if (!gameOver) {
    
    //basket movment
    if (keyIsDown(LEFT_ARROW)) basket.position.x -= 5;
    if (keyIsDown(RIGHT_ARROW)) basket.position.x += 5;

    //keep basket from going out of bounds
    basket.position.x = constrain(basket.position.x, 40, width - 40);

    //spawn items to catch every second
    if (frameCount % 60 === 0) {

      let item = createSprite(random(20, width - 20), 0, 20, 20);
      item.velocity.y = 5;
      items.push(item);

    }

    //check for colliding items with basket
    for (let i = items.length - 1; i >= 0; i--) {

      if (basket.overlap(items[i])) {

        items[i].remove();
        items.splice(i, 1);
        score++;

      } else if (items[i].position.y > height) {

        gameOver = true;

      }

    }

    //draw all sprites
    drawSprites();

    //display score
    textSize(20);
    fill(0);
    text("Score: " + score, 10, 20);

  } else {

    //game over msg
    textSize(30);
    fill(255, 0, 0);
    textAlign(CENTER, CENTER);
    text("Game Over", width / 2, height / 2);
    
    textSize(20);
    text("Final Score: " + score, width / 2, height / 2 + 40);

  }

}