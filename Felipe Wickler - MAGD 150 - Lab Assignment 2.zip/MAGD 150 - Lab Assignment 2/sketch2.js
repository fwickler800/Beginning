function setup() {
  
    createCanvas(200, 200);
    background(220);
    colorMode(RGB,100,100,100,0.2);
  }
  
  function draw() {
    
    fill(100,0,0);
    ellipse(50, 20, 20, 30);
    line(50,35,50,55);
    fill(10,100,0);
    ellipse(75,80,20,30);
    line(75,95,75,115);
    fill(45,45,0);
    ellipse(100,40,20,30);
    line(100,55,100,75);
    fill(0,0,100);
    ellipse(150,65,20,30);
    line(150,80,150,100);
    fill(100,100,100);
    arc(150,10,40,20, PI, HALF_PI);
    arc(130,10,40,20, 0, PI + HALF_PI);
    fill(50,100,50);
    triangle(100,150,120,170,80,170);
    fill(65,45,0);
    quad(90,170,110,170,90,200,110,200);
    
  }