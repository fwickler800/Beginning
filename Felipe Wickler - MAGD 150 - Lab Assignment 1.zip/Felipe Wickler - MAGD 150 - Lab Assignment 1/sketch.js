function setup() {

    createCanvas(128, 128);
    
  }
  
function draw() {
  
    fill(150);
    background(220);
    rect(0,98,20,30);
    rect(5,103,10,20);
    rect(20,58,30,70);
    line(25,63,25,123);
    strokeJoin(ROUND);
    rect(50,78,25,50);
    line(55,83,55,123);
    rect(75,108,53,20);
    rect(80,113,20,10);
    ellipse(90,20,20,20);
    noFill();
    ellipse(80,30,15,15);
    ellipse(70,40,10,10);
    ellipse(60,50,5,5);
  
}