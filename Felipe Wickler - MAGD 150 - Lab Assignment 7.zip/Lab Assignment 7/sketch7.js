// Function to create a retro pixel-art-like shape
function retroShape() {

    noStroke();
    fill(200, 100, 150); 
    rect(0, 0, 30, 30); 
    fill(255, 255, 0); 
    rect(10, 10, 10, 10); 
    fill(0, 255, 255);
    ellipse(15, 15, 5, 5); 
    
}
  
// Function that returns a random scale factor
function getRandomScale() {

    let scaleFactor = random(0.5, 2);
    print("Scale factor: ", scaleFactor); 
    return scaleFactor;

}
  
function setup() {

    createCanvas(400, 400);
    background(50);
  
    angleMode(DEGREES); 
  
    for (let i = 0; i < 8; i++) {

      push(); 
      let x = random(50, 350);
      let y = random(50, 350);
  
      // Random scale and rotation
      let s = getRandomScale();
      let rotation = random(0, 360);
  
      translate(x, y); // Move shape to random position
      scale(s); 
      rotate(rotation); 
  
      retroShape(); 
      pop(); 

    }

}