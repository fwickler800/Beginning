let carrotIMG, lemonIMG, basketIMG;

function preload() {
  
  carrotIMG = loadImage('/Images/Carrot.png');
  lemonIMG = loadImage('/Images/Lemon.png');
  basketIMG = loadImage('/Images/Basket.jpg');
  
}

function setup() {
  
  createCanvas(400, 400);
  textFont('Helvetica');
  textAlign(CENTER);
  textSize(20);
  frameRate(120);
  
}

function draw() {
  
  background(220);
  image(basketIMG, mouseX - 100 , 200);
  image(carrotIMG, 200, 250);
  image(lemonIMG, mouseX - 32, mouseY - 32); // -32 centers it on the mouse
  
  fill(255, 0, 0);
  stroke(60);
  strokeWeight(2);
  text('Fruit Basket', 200, 50, 100, 100);
  
}