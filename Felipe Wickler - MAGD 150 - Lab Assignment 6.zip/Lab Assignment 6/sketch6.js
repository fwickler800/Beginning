let xPos = []; // x-positions for fireflies
let yPos = []; // y-position for fireflies
let numFireflies = 10; // number of fireflies
      
    function setup() {
        
        createCanvas(600, 600);
        
        for (let i = 0; i < numFireflies; i++) {
          
          xPos[i] = random(width); // Assign random values to the arrays
          yPos[i] = random(height);
          
        }

        print(xPos.length); // Print the lengths of the arrays
        print(yPos.length);
        
    }

function draw() {
        
  background(20, 20, 50); // Dark background for Halloween theme
  fill(255, 165, 0); // Halloween orange
  noStroke();
        
    // Update array values and create motion
    for (let i = 0; i < numFireflies; i++) {
          
      ellipse(xPos[i], yPos[i], 30, 30); // Draw shapes using array values for x and y-positions
      xPos[i] += random(-2, 2); // Create slight motion on the axes like the fireflies are flying
      yPos[i] += random(-2, 2);
          
      // Use mouseX and mouseY in one of the positions when mouse is pressed
      if (mouseIsPressed) {
            
        xPos[i] = mouseX;
        yPos[i] = mouseY;
            
      }
          
  }
        
  // Title text
  textAlign(CENTER);
  textSize(20);
  textFont('Courier New');
  text("Fireflies in the Night", 300, 50);
        
  // Instruction text
  textSize(12);
  textFont('Verdana');
  text("Click anywhere to attract the fireflies", 300, 550);
        
}