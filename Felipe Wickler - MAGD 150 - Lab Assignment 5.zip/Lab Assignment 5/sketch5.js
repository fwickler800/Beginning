let rectButtonColor, ellipseButtonColor, keyButtonColor;
let colorPalette = ['#1F3F49', '#406373', '#6C848D', '#F1F6F8', '#BBE1FA'];
let rectX = 50, rectY = 300, rectWidth = 100, rectHeight = 50;
let ellipseX = 300, ellipseY = 100, ellipseRadius = 60;
let keyX = 250, keyY = 300, keyWidth = 100, keyHeight = 50;
let keyToPress = 'k'; // Key to press for the keyButton

function setup() {
  
  createCanvas(400, 400);
  rectButtonColor = colorPalette[1];
  ellipseButtonColor = colorPalette[2];
  keyButtonColor = colorPalette[3];

}

function draw() {
  
  background(colorPalette[0]);

  // Draw rectangle button
  fill(rectButtonColor);
  rect(rectX, rectY, rectWidth, rectHeight);

  // Draw ellipse button
  fill(ellipseButtonColor);
  ellipse(ellipseX, ellipseY, ellipseRadius);

  // Draw key-based rectangle button
  fill(keyButtonColor);
  rect(keyX, keyY, keyWidth, keyHeight);

  // Instruction Text
  fill(255);
  textSize(12);
  textAlign(CENTER);
  text('Click the buttons or press "K" for the key button while hovering over it', width / 2, height - 20);

  textSize(20);
  text('KEY BUTTON', keyWidth / 2 + keyX, keyY - 20);
}

// Key pressed for key-based button
function keyPressed() {
        
  if (key === keyToPress && mouseX >= keyX && mouseX <= keyX + keyWidth && mouseY >= keyY && mouseY <= keyY + keyHeight) {
          
    keyButtonColor = color(random(255), random(255), random(255));
      
  }
      
}

// Mouse click for rectangle button
function mousePressed() {
  
  if (mouseX >= rectX && mouseX <= rectX + rectWidth && mouseY >= rectY && mouseY <= rectY + rectHeight) {
    
    rectButtonColor = color(random(255), random(255), random(255));
    
  }
        
  if (dist(mouseX, mouseY, ellipseX, ellipseY) <= ellipseRadius / 2) {
          
    ellipseButtonColor = color(random(255), random(255), random(255));
        
  }
      
}